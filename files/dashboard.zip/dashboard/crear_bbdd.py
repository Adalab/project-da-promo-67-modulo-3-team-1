# ==========================================================
# crear_bbdd.py — FASE 4/5: Creación de la BBDD SQLite
# ==========================================================
# ¿Qué hace este archivo?
#   Lee el csv limpio y lo convierte en una base de datos
#   SQLite (talento.db). Así el dashboard puede hacer las
#   consultas en SQL de verdad, como pide el proyecto.
#
# ¿Por qué SQLite?
#   Es una BBDD real que vive en UN solo archivo (.db),
#   no necesita instalar servidor (a diferencia de MySQL).
#   Perfecta para demos y proyectos.
# ==========================================================

import sqlite3          # librería estándar de Python para hablar con SQLite (ya viene instalada)
from pathlib import Path  # para construir rutas que funcionan igual en Windows, Mac y Linux
import pandas as pd     # para leer el csv y volcarlo a la BBDD

# CARPETA = la carpeta donde está ESTE archivo (dashboard/).
# ¿Por qué? Así el script funciona aunque lo ejecutes desde otra carpeta.
CARPETA = Path(__file__).parent

# RUTA_CSV = el csv limpio. Lo buscamos primero en la carpeta padre
# (Proyecto/) y, si no está, en esta misma carpeta (dashboard/).
# ¿Por qué? Así el dashboard también funciona si se comparte SOLO
# la carpeta dashboard con el csv dentro (ej.: enviárselo a la profe).
if (CARPETA.parent / "hr_limpio.csv").exists():
    RUTA_CSV = CARPETA.parent / "hr_limpio.csv"
else:
    RUTA_CSV = CARPETA / "hr_limpio.csv"

# RUTA_BBDD = dónde se creará la base de datos
RUTA_BBDD = CARPETA / "talento.db"


def crear_base_de_datos():
    """
    Crea (o recrea) la BBDD talento.db con la tabla 'empleados'.

    Pasos:
      1. Lee hr_limpio.csv con pandas.
      2. Abre conexión a SQLite (si el .db no existe, lo crea).
      3. Vuelca el DataFrame a una tabla SQL llamada 'empleados'.

    Devuelve el número de filas insertadas (para comprobar que fue bien).
    """
    df = pd.read_csv(RUTA_CSV)                 # 1. csv -> DataFrame
    conexion = sqlite3.connect(RUTA_BBDD)      # 2. abrir/crear la BBDD

    # 3. DataFrame -> tabla SQL.
    #    if_exists="replace": si la tabla ya existía, la sustituye
    #    (así siempre tienes los datos más frescos = idea de una ETL).
    #    index=False: no guardamos el índice de pandas como columna.
    df.to_sql("empleados", conexion, if_exists="replace", index=False)

    conexion.close()                           # cerrar SIEMPRE la conexión
    return len(df)


# Este bloque solo se ejecuta si lanzas "python crear_bbdd.py" directamente.
# Si otro archivo hace "import crear_bbdd", NO se ejecuta solo. Es la forma
# estándar en Python de separar "usar como módulo" de "ejecutar como script".
if __name__ == "__main__":
    filas = crear_base_de_datos()
    print(f"✅ BBDD creada en {RUTA_BBDD} con {filas} empleados.")
