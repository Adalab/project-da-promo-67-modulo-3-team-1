# ==========================================================
# app.py — Dashboard "Retención del Talento" · ABC Corporation
# Estilo SPC: fondo negro, colores vivos, sidebar a la izquierda
# ==========================================================
# Estructura del archivo (léelo en este orden):
#   1. IMPORTS        -> herramientas
#   2. CONSTANTES     -> colores, rutas, textos
#   3. FUNCIONES SQL  -> filtros y consultas
#   4. GRÁFICOS       -> una figura por pregunta
#   5. LECTURAS       -> interpretación en lenguaje natural
#   6. LAYOUT         -> sidebar izquierda + panel de gráficos
#   7. CALLBACK       -> la interactividad
#   8. ARRANQUE
# ==========================================================

# ---------- 1. IMPORTS ----------
import sqlite3
from pathlib import Path

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import warnings
warnings.filterwarnings("ignore")

from dash import Dash, dcc, html, Input, Output

from consultas_sql import PREGUNTAS
import crear_bbdd

# ---------- 2. CONSTANTES ----------
CARPETA = Path(__file__).parent
RUTA_BBDD = CARPETA / "talento.db"

if not RUTA_BBDD.exists():
    crear_bbdd.crear_base_de_datos()

C = {
    "fondo":    "#0b0b12",
    "panel":    "#161622",
    "borde":    "#2a2a3d",
    "texto":    "#e8e8f0",
    "texto2":   "#8a8aa3",
    "cian":     "#00e5ff",
    "rosa":     "#ff2d78",
    "amarillo": "#ffd166",
    "verde":    "#2ee6a8",
    "violeta":  "#9d6bff",
}
SECUENCIA = [C["cian"], C["rosa"], C["amarillo"], C["verde"], C["violeta"]]

# Columna numérica para el panel de estadísticas de cada pregunta
COL_STATS = {
    "Q1": "JobSatisfaction", "Q2": "JobSatisfaction", "Q3": "JobSatisfaction",
    "Q4": "WorkLifeBalance", "Q5": "MonthlyIncome",   "Q6": "MonthlyIncome",
    "Q8": "YearsAtCompany",  "Q9": "DistanceFromHome","Q10": "JobSatisfaction",
    "Q11": "YearsAtCompany", "Q12": "MonthlyIncome",  "Q13": "Age",
    "Q14": "DistanceFromHome", "Q15": "MonthlyIncome",
}
NOMBRE_COL = {
    "JobSatisfaction": "Satisfacción laboral (1-4)",
    "WorkLifeBalance": "Balance vida-trabajo (1-4)",
    "MonthlyIncome": "Salario mensual ($)",
    "Age": "Edad",
    "YearsAtCompany": "Años en la empresa",
    "DistanceFromHome": "Distancia al trabajo (km)",
}
# Etiquetas legibles para Attrition
ETIQUETA_ESTADO = {"Yes": "Se va", "No": "Se queda"}
COLOR_ESTADO = {"Se va": "#ff2d78", "Se queda": "#00e5ff"}

# ---------- 3. FUNCIONES SQL ----------

def construir_where(departamentos, genero, overtime, rango_edad):
    """Convierte los filtros del dashboard en un trozo de SQL (3 variantes)."""
    condiciones = []
    if departamentos:
        deps = ", ".join(f"'{d}'" for d in departamentos)
        condiciones.append(f"Department IN ({deps})")
    if genero:
        gens = ", ".join(f"'{g}'" for g in genero)
        condiciones.append(f"Gender IN ({gens})")
    if overtime in ("Yes", "No"):
        condiciones.append(f"OverTime = '{overtime}'")
    if rango_edad and rango_edad != [18, 60]:
        condiciones.append(f"Age BETWEEN {rango_edad[0]} AND {rango_edad[1]}")
    filtros = " AND ".join(condiciones)
    return {
        "where":     f"WHERE {filtros}" if filtros else "",
        "where_and": f"WHERE {filtros} AND" if filtros else "WHERE",
        "where_sub": f"WHERE {filtros} AND" if filtros else "WHERE",
    }


def ejecutar_sql(sql):
    """Abre conexión, ejecuta la consulta y devuelve un DataFrame."""
    conexion = sqlite3.connect(RUTA_BBDD)
    resultado = pd.read_sql(sql, conexion)
    conexion.close()
    return resultado


def datos_filtrados(w):
    """Todos los empleados que pasan los filtros (para KPIs y estadísticas)."""
    return ejecutar_sql(f"SELECT * FROM empleados {w['where']}")


# ---------- 4. GRÁFICOS ----------

def estilo_oscuro(fig, titulo=""):
    """Tema negro para cualquier figura (DRY: se escribe una vez)."""
    fig.update_layout(
        title=dict(text=titulo, font=dict(size=17, color=C["texto"])),
        paper_bgcolor=C["fondo"], plot_bgcolor=C["fondo"],
        font=dict(color=C["texto"], family="Segoe UI, sans-serif"),
        legend=dict(bgcolor=C["panel"], bordercolor=C["borde"], borderwidth=1),
        margin=dict(l=50, r=30, t=60, b=50),
    )
    fig.update_xaxes(gridcolor=C["borde"], zerolinecolor=C["borde"])
    fig.update_yaxes(gridcolor=C["borde"], zerolinecolor=C["borde"])
    return fig


def figura_vacia(mensaje):
    fig = go.Figure()
    fig.add_annotation(text=mensaje, showarrow=False, font=dict(size=16, color=C["texto2"]))
    return estilo_oscuro(fig)


def semaforo(tasa):
    """Color según la tendencia a irse: rojo-rosado alta, amarillo media, turquesa baja."""
    if tasa >= 20:
        return C["rosa"]
    if tasa >= 10:
        return C["amarillo"]
    return C["cian"]


def crear_grafico(qid, res, df):
    """Devuelve la figura de cada pregunta (qid) a partir del resultado SQL (res)."""
    if res.empty or df.empty:
        return figura_vacia("Sin datos con estos filtros. Prueba a ampliar la selección.")

    if qid == "Q1":  # satisfacción media: Sí (izquierda) vs No (derecha)
        res = res.copy()
        res["grupo"] = res["grupo"].map({"Yes": "Sí horas extras", "No": "No horas extras"})
        orden = ["Sí horas extras", "No horas extras"]  # 2.82 a la izquierda, 2.73 a la derecha
        fig = px.bar(res, x="grupo", y="satisfaccion_media", text="satisfaccion_media",
                     color="grupo", category_orders={"grupo": orden},
                     color_discrete_map={"Sí horas extras": C["rosa"], "No horas extras": C["verde"]})
        fig.update_traces(textposition="outside")
        fig.update_yaxes(range=[0, 4], title="Satisfacción media (1-4)")
        fig.update_xaxes(title="", categoryorder="array", categoryarray=orden)
        return estilo_oscuro(fig, "Satisfacción media según horas extras")

    if qid == "Q2":
        fig = px.bar(res, x="nivel_satisfaccion", y="tasa_abandono", text="tasa_abandono",
                     color="tasa_abandono", color_continuous_scale=[C["verde"], C["amarillo"], C["rosa"]])
        fig.update_traces(texttemplate="%{text}%", textposition="outside")
        fig.update_xaxes(title="Nivel de satisfacción (1 = baja, 4 = alta)", dtick=1)
        fig.update_yaxes(title="Tasa de abandono (%)")
        fig.update_coloraxes(showscale=False)
        return estilo_oscuro(fig, "A menor satisfacción, mayor fuga de talento")

    if qid == "Q3":
        fig = px.pie(res, names="perfil", values="empleados", hole=0.55,
                     color_discrete_sequence=[C["rosa"], C["amarillo"], C["violeta"], C["cian"]])
        fig.update_traces(textinfo="percent+label", textfont_size=12)
        return estilo_oscuro(fig, "Perfil de los empleados que se fueron")

    if qid == "Q4":  # ordenado de menor a mayor; las 2 mayores en colores llamativos
        res = res.sort_values("empleados_en_riesgo", ascending=True).copy()
        res["etiqueta"] = res["puesto"] + " · " + res["departamento"]
        n = len(res)
        colores = [C["cian"]] * n
        if n >= 1: colores[-1] = C["rosa"]      # la mayor
        if n >= 2: colores[-2] = C["amarillo"]  # la segunda mayor
        fig = go.Figure(go.Bar(
            x=res["empleados_en_riesgo"], y=res["etiqueta"], orientation="h",
            marker_color=colores, text=res["empleados_en_riesgo"], textposition="outside",
        ))
        fig.update_yaxes(title="", autorange="reversed")  # menor arriba, mayor abajo
        fig.update_xaxes(title="Empleados actuales en riesgo")
        return estilo_oscuro(fig, "Talento en riesgo de fuga (aún están, pero...)")

    if qid == "Q5":  # barra mayor a la izquierda
        res = res.sort_values("salario_medio", ascending=False)
        fig = px.bar(res, x="grupo", y="salario_medio", text="salario_medio",
                     color="grupo",
                     color_discrete_map={"Sobrecargados": C["rosa"], "Resto de la plantilla": C["cian"]})
        fig.update_traces(texttemplate="$%{text:,.0f}", textposition="outside")
        fig.update_xaxes(title="", categoryorder="array", categoryarray=list(res["grupo"]))
        fig.update_yaxes(title="Salario mensual medio ($)")
        return estilo_oscuro(fig, "¿Se compensa la sobrecarga con salario?")

    if qid == "Q6":  # dispersión con la correlación de cada nivel en la leyenda
        res = res.copy()
        # correlación experiencia-salario DENTRO de cada nivel (se recalcula con los filtros)
        corrs = {}
        for nivel, grupo in res.groupby("nivel_puesto"):
            c = grupo["anios_experiencia"].corr(grupo["salario_mensual"])
            corrs[nivel] = 0.0 if pd.isna(c) else round(c, 2)
        res["nivel_txt"] = res["nivel_puesto"].map(lambda n: f"Nivel {n} ({corrs[n]})")
        orden_niveles = [f"Nivel {n} ({corrs[n]})" for n in sorted(corrs)]
        fig = px.scatter(res, x="anios_experiencia", y="salario_mensual",
                         color="nivel_txt", opacity=0.6,
                         category_orders={"nivel_txt": orden_niveles},
                         color_discrete_sequence=SECUENCIA)
        m, b = np.polyfit(res["anios_experiencia"], res["salario_mensual"], 1)
        x_linea = np.array([res["anios_experiencia"].min(), res["anios_experiencia"].max()])
        fig.add_trace(go.Scatter(x=x_linea, y=m * x_linea + b, mode="lines",
                                 name="Tendencia global", line=dict(color="white", dash="dash")))
        fig.update_xaxes(title="Años de experiencia total")
        fig.update_yaxes(title="Salario mensual ($)")
        fig.update_layout(legend_title_text="Nivel (correlación)")
        return estilo_oscuro(fig, "Experiencia vs. salario, por nivel de puesto")

    if qid == "Q8":  # barra mayor (Sí) a la izquierda
        res = res.copy()
        res["horas_extra"] = res["horas_extra"].map({"Yes": "Sí horas extras", "No": "No horas extras"})
        res = res.sort_values("tasa_abandono", ascending=False)
        fig = px.bar(res, x="horas_extra", y="tasa_abandono", text="tasa_abandono",
                     color="horas_extra",
                     color_discrete_map={"Sí horas extras": C["rosa"], "No horas extras": C["verde"]})
        fig.update_traces(texttemplate="%{text}%", textposition="outside")
        fig.update_xaxes(title="", categoryorder="array", categoryarray=list(res["horas_extra"]))
        fig.update_yaxes(title="Tasa de abandono (%)")
        return estilo_oscuro(fig, "Las horas extras disparan el abandono")

    if qid == "Q9":
        orden = ["Non-Travel", "Travel_Rarely", "Travel_Frequently"]
        res["frecuencia_viajes"] = pd.Categorical(res["frecuencia_viajes"], orden, ordered=True)
        res = res.sort_values("frecuencia_viajes")
        fig = px.bar(res, x="frecuencia_viajes", y="tasa_abandono", text="tasa_abandono",
                     color="tasa_abandono", color_continuous_scale=[C["verde"], C["amarillo"], C["rosa"]])
        fig.update_traces(texttemplate="%{text}%", textposition="outside")
        fig.update_xaxes(title="Frecuencia de viajes de trabajo")
        fig.update_yaxes(title="Tasa de abandono (%)")
        fig.update_coloraxes(showscale=False)
        return estilo_oscuro(fig, "Cuanto más se viaja, más se abandona")

    if qid == "Q10":  # menor a mayor + semáforo de colores
        res = res.sort_values("tasa_abandono", ascending=True).copy()
        res["etiqueta"] = res["puesto"] + " · " + res["departamento"]
        colores = [semaforo(t) for t in res["tasa_abandono"]]
        fig = go.Figure(go.Bar(
            x=res["tasa_abandono"], y=res["etiqueta"], orientation="h",
            marker_color=colores, text=res["tasa_abandono"],
            texttemplate="%{text}%", textposition="outside",
        ))
        fig.update_yaxes(title="", autorange="reversed")  # menor arriba, mayor abajo
        fig.update_xaxes(title="Tasa de abandono (%)")
        return estilo_oscuro(fig, "Radiografía del abandono por puesto")

    # ---- Preguntas añadidas desde el notebook fase-3 ----
    res = res.copy()
    if "estado" in res.columns:
        res["estado"] = res["estado"].map(ETIQUETA_ESTADO)

    if qid == "Q11":  # antigüedad según rotación (histograma superpuesto)
        fig = px.histogram(res, x="anios_empresa", color="estado", nbins=20,
                           barmode="overlay", opacity=0.75, color_discrete_map=COLOR_ESTADO)
        for estado, grupo in res.groupby("estado"):
            fig.add_vline(x=grupo["anios_empresa"].median(), line_dash="dash",
                          line_color=COLOR_ESTADO[estado],
                          annotation_text=f"mediana {estado}: {grupo['anios_empresa'].median():.0f}",
                          annotation_font_color=COLOR_ESTADO[estado])
        fig.update_xaxes(title="Años en la empresa")
        fig.update_yaxes(title="Número de empleados")
        return estilo_oscuro(fig, "La rotación se concentra en los primeros años")

    if qid == "Q12":  # salario y rotación (boxplot)
        fig = px.box(res, x="estado", y="salario_mensual", color="estado",
                     color_discrete_map=COLOR_ESTADO,
                     category_orders={"estado": ["Se va", "Se queda"]})
        fig.update_traces(boxmean=True)
        fig.update_xaxes(title="")
        fig.update_yaxes(title="Salario mensual ($)")
        return estilo_oscuro(fig, "Los que se van cobran claramente menos")

    if qid == "Q13":  # edad y rotación (histograma superpuesto)
        fig = px.histogram(res, x="edad", color="estado", nbins=20,
                           barmode="overlay", opacity=0.75, color_discrete_map=COLOR_ESTADO)
        for estado, grupo in res.groupby("estado"):
            fig.add_vline(x=grupo["edad"].median(), line_dash="dash",
                          line_color=COLOR_ESTADO[estado],
                          annotation_text=f"mediana {estado}: {grupo['edad'].median():.0f}",
                          annotation_font_color=COLOR_ESTADO[estado])
        fig.update_xaxes(title="Edad")
        fig.update_yaxes(title="Número de empleados")
        return estilo_oscuro(fig, "El talento joven es el que más se marcha")

    if qid == "Q14":  # distancia al trabajo (boxplot)
        fig = px.box(res, x="estado", y="distancia_km", color="estado",
                     color_discrete_map=COLOR_ESTADO,
                     category_orders={"estado": ["Se va", "Se queda"]})
        fig.update_traces(boxmean=True)
        fig.update_xaxes(title="")
        fig.update_yaxes(title="Distancia al trabajo (km)")
        return estilo_oscuro(fig, "Vivir lejos también empuja a la puerta")

    if qid == "Q15":  # salario según horas extras (mayor a la izquierda)
        res["horas_extra"] = res["horas_extra"].map({"Yes": "Sí horas extras", "No": "No horas extras"})
        res = res.sort_values("salario_medio", ascending=False)
        fig = px.bar(res, x="horas_extra", y="salario_medio", text="salario_medio",
                     color="horas_extra",
                     color_discrete_map={"Sí horas extras": C["amarillo"], "No horas extras": C["cian"]})
        fig.update_traces(texttemplate="$%{text:,.0f}", textposition="outside")
        fig.update_xaxes(title="", categoryorder="array", categoryarray=list(res["horas_extra"]))
        fig.update_yaxes(title="Salario mensual medio ($)")
        return estilo_oscuro(fig, "¿Se pagan mejor las horas extras?")

    return figura_vacia("Pregunta no reconocida")


# ---------- 5. LECTURAS DEL ANALISTA ----------

def interpretar(qid, res, df):
    """Texto en lenguaje natural con los números reales (se recalcula al filtrar)."""
    if res.empty or df.empty:
        return "No hay datos con los filtros actuales."
    try:
        if qid == "Q1":
            d = dict(zip(res["grupo"], res["satisfaccion_media"]))
            return (f"Los empleados CON horas extras puntúan su satisfacción en {d.get('Yes', '—')} "
                    f"y los que NO en {d.get('No', '—')} (sobre 4). La diferencia es mínima: "
                    f"la insatisfacción no está en el 'cuánto trabajo', sino en cómo se compensa y reconoce.")
        if qid == "Q2":
            r = res.sort_values("nivel_satisfaccion")
            return (f"El {r.iloc[0]['tasa_abandono']}% de los empleados con satisfacción mínima (1) se va, "
                    f"frente al {r.iloc[-1]['tasa_abandono']}% de los más satisfechos (4). "
                    f"Subir la satisfacción es, literalmente, retener talento.")
        if qid == "Q3":
            fila = res[res["perfil"] == "Horas extras + Satisf. baja"]
            pct = fila["porcentaje"].iloc[0] if not fila.empty else 0
            return (f"De todos los que abandonaron, el {pct}% combinaba horas extras con satisfacción baja. "
                    f"Es el perfil 'quemado': mucha carga y poca recompensa emocional.")
        if qid == "Q4":
            total = int(res["empleados_en_riesgo"].sum())
            deps = res.groupby("departamento")["empleados_en_riesgo"].sum().to_dict()
            detalle = ", ".join(f"{v} en {k}" for k, v in deps.items())
            return (f"Hay {total} empleados actuales con el 'combo de riesgo' (horas extras + mal balance "
                    f"+ baja satisfacción): {detalle}. Son la lista prioritaria de RRHH para actuar YA.")
        if qid == "Q5":
            d = dict(zip(res["grupo"], res["salario_medio"]))
            sob, resto = d.get("Sobrecargados", 0), d.get("Resto de la plantilla", 0)
            dif = round(100 * (sob - resto) / resto, 1) if resto else 0
            return (f"Los sobrecargados ganan ${sob:,.0f} frente a ${resto:,.0f} del resto: "
                    f"solo un {dif}% más. La sobrecarga NO se está compensando económicamente.")
        if qid == "Q6":
            corr = round(res["anios_experiencia"].corr(res["salario_mensual"]), 2)
            return (f"A nivel global, experiencia y salario van muy de la mano (correlación {corr}). "
                    f"PERO dentro de cada nivel de puesto la relación casi desaparece: el salario sube "
                    f"al ASCENDER de nivel, no por acumular años. Sin promociones, la experiencia no "
                    f"se paga y AUMENTA la insatisfacción.")
        if qid == "Q8":
            d = dict(zip(res["horas_extra"], res["tasa_abandono"]))
            si, no = d.get("Yes", 0), d.get("No", 0)
            veces = round(si / no, 1) if no else 0
            return (f"Sí, y de forma contundente: el {si}% de quienes hacen horas extras se va, "
                    f"frente al {no}% de quienes no. Hacer horas extras multiplica por {veces} "
                    f"la probabilidad de perder a esa persona.")
        if qid == "Q9":
            d = dict(zip(res["frecuencia_viajes"].astype(str), res["tasa_abandono"]))
            return (f"Sí: quienes viajan con frecuencia abandonan al {d.get('Travel_Frequently')}%, casi el triple "
                    f"que quienes no viajan ({d.get('Non-Travel')}%). El viaje constante desgasta; conviene "
                    f"rotar los viajes o compensarlos.")
        if qid == "Q10":
            top = res.sort_values("tasa_abandono", ascending=False).iloc[0]
            return (f"El abandono no golpea igual a todos los puestos. El más crítico es {top['puesto']} "
                    f"({top['departamento']}): {top['tasa_abandono']}% de rotación, prácticamente el doble "
                    f"que el resto. Determinados perfiles, sobre todo los comerciales, están mucho más "
                    f"expuestos: ahí es donde un plan de choque tendría más impacto inmediato.")
        if qid == "Q11":
            med = res.groupby("estado")["anios_empresa"].median().to_dict()
            return (f"La rotación se concentra en los primeros años de contrato: la mitad de quienes se van "
                    f"no llega a {med.get('Yes', 3):.0f} años en la empresa, frente a la mediana de "
                    f"{med.get('No', 6):.0f} años de quienes se quedan. El período crítico es el arranque: "
                    f"un buen onboarding y un plan de carrera temprano marcan la diferencia.")
        if qid == "Q12":
            medias = res.groupby("estado")["salario_mensual"].mean().to_dict()
            medianas = res.groupby("estado")["salario_mensual"].median().to_dict()
            return (f"Existe una diferencia salarial clara: quienes abandonan cobran de media "
                    f"${medias.get('Yes', 0):,.0f} frente a ${medias.get('No', 0):,.0f} de quienes permanecen "
                    f"(medianas: ${medianas.get('Yes', 0):,.0f} vs ${medianas.get('No', 0):,.0f}). "
                    f"La fuga se concentra en los rangos salariales más bajos.")
        if qid == "Q13":
            medias = res.groupby("estado")["edad"].mean().to_dict()
            return (f"La edad influye: quienes se van tienen de media {medias.get('Yes', 0):.1f} años, "
                    f"frente a los {medias.get('No', 0):.1f} de quienes se quedan. El talento joven es el "
                    f"más volátil; necesita proyecto y crecimiento desde el primer día.")
        if qid == "Q14":
            medias = res.groupby("estado")["distancia_km"].mean().to_dict()
            return (f"Quienes abandonan viven de media a {medias.get('Yes', 0):.1f} km del trabajo, frente a "
                    f"los {medias.get('No', 0):.1f} km de quienes permanecen. La distancia pesa: teletrabajo "
                    f"o flexibilidad horaria ayudarían a retener a los que viven lejos.")
        if qid == "Q15":
            d = dict(zip(res["horas_extra"], res["salario_medio"]))
            si, no = d.get("Yes", 0), d.get("No", 0)
            dif = round(100 * (si - no) / no, 1) if no else 0
            return (f"Los que hacen horas extras cobran de media ${si:,.0f} frente a ${no:,.0f} de quienes no "
                    f"las hacen: apenas un {dif}% más. El esfuerzo adicional no se refleja en la nómina, "
                    f"y eso alimenta la fuga que vimos en la pregunta 8.")
    except Exception as e:
        return f"(No se pudo generar la interpretación: {e})"
    return ""


def calcular_estadisticas(qid, df):
    """Media, mediana, moda, desviación y asimetría de la columna de la pregunta."""
    col = COL_STATS[qid]
    serie = df[col]
    if serie.empty:
        return [html.P("Sin datos", style={"color": C["texto2"]})]
    asimetria = round(serie.skew(), 2)
    if asimetria > 0.5:
        lectura = "asimetría positiva: la mayoría está por DEBAJO de la media (cola a la derecha)"
    elif asimetria < -0.5:
        lectura = "asimetría negativa: la mayoría está por ENCIMA de la media (cola a la izquierda)"
    else:
        lectura = "distribución bastante simétrica: la media es representativa"
    stats = [
        ("Media", round(serie.mean(), 2)),
        ("Mediana", round(serie.median(), 2)),
        ("Moda", serie.mode().iloc[0]),
        ("Desv. típica", round(serie.std(), 2)),
        ("Asimetría", asimetria),
    ]
    filas = [html.P(f"Variable: {NOMBRE_COL[col]}",
                    style={"color": C["cian"], "fontWeight": "600", "marginBottom": "8px"})]
    for nombre, valor in stats:
        filas.append(html.Div([
            html.Span(nombre, style={"color": C["texto2"]}),
            html.Span(f"{valor:,}" if isinstance(valor, (int, float)) else str(valor),
                      style={"color": C["texto"], "fontWeight": "700"}),
        ], style={"display": "flex", "justifyContent": "space-between",
                  "borderBottom": f"1px solid {C['borde']}", "padding": "6px 0"}))
    filas.append(html.P(lectura, style={"color": C["amarillo"], "fontSize": "12px", "marginTop": "10px"}))
    return filas


# ---------- 6. LAYOUT ----------

ESTILO_TARJETA = {"backgroundColor": C["panel"], "border": f"1px solid {C['borde']}",
                  "borderRadius": "12px", "padding": "18px", "marginBottom": "16px"}


def icono(src, alto=34):
    """Imagen pequeña con bordes redondeados para usar como icono de sección."""
    return html.Img(src=src, style={"height": f"{alto}px", "width": f"{alto}px",
                                    "borderRadius": "8px", "objectFit": "cover",
                                    "marginRight": "10px", "verticalAlign": "middle"})


def titulo_seccion(texto_titulo, img=None, alto=34):
    """Encabezado de tarjeta: icono de imagen (opcional) + texto alineados."""
    contenido = ([icono(img, alto)] if img else []) + [
        html.Span(texto_titulo, style={"color": C["texto"], "fontWeight": "700", "fontSize": "17px"})]
    return html.Div(contenido, style={"display": "flex", "alignItems": "center",
                                      "marginBottom": "12px"})


def tarjeta_kpi(id_valor, etiqueta, color):
    return html.Div([
        html.Div(id=id_valor, style={"fontSize": "24px", "fontWeight": "800", "color": color}),
        html.Div(etiqueta, style={"fontSize": "11px", "color": C["texto2"]}),
    ], style={**ESTILO_TARJETA, "flex": "1", "textAlign": "center", "marginBottom": "0",
              "padding": "14px"})


app = Dash(__name__)
app.title = "ABC Corp · Retención del Talento"

app.layout = html.Div(style={"backgroundColor": C["fondo"], "minHeight": "100vh",
                             "fontFamily": "Segoe UI, sans-serif"}, children=[

    # ---- Banner superior ----
    html.Div([
        html.Div([
            html.H1("ABC Corporation", style={"color": C["texto"], "margin": "0", "fontSize": "24px"}),
            html.P("Análisis de Retención del Talento · Dashboard interactivo",
                   style={"color": C["texto2"], "margin": "0", "fontSize": "13px"}),
        ]),
        html.Div([
            html.Div("People Analytics", style={"color": C["cian"], "fontWeight": "700",
                                                "textAlign": "right"}),
            html.Div([
                html.Div("Alexa Prieto", style={"color": "white", "fontSize": "12px", "textAlign": "right"}),
                html.Div("Checha Martinez", style={"color": "white", "fontSize": "12px", "textAlign": "right"}),
                html.Div("Cris Saenz", style={"color": "white", "fontSize": "12px", "textAlign": "right"}),
                html.Div("Nati Guerrero", style={"color": "white", "fontSize": "12px", "textAlign": "right"}),
            ], style={"marginTop": "4px"}),
        ]),
    ], style={"display": "flex", "justifyContent": "space-between", "alignItems": "flex-start",
              "padding": "16px 30px", "borderBottom": f"1px solid {C['borde']}",
              "backgroundColor": C["panel"]}),

    # ---- Cuerpo: sidebar izquierda + panel de gráficos ----
    html.Div([

        # ===== SIDEBAR IZQUIERDA: preguntas y filtros =====
        html.Div([
            html.Div([
                titulo_seccion("Preguntas y filtros"),
                html.Label("Pregunta de negocio", style={"color": C["cian"], "fontWeight": "600",
                                                         "fontSize": "13px"}),
                dcc.Dropdown(
                    id="selector-pregunta",
                    options=[{"label": p["titulo"], "value": qid} for qid, p in PREGUNTAS.items()],
                    value="Q8",
                    clearable=False,
                    searchable=False,            # sin buscador, lo quito para evitar ruido visual
                    className="dropdown-oscuro", # estilos oscuros en assets/estilos.css
                    style={"marginTop": "6px", "marginBottom": "20px"},
                ),

                html.Label("Departamento", style={"color": C["cian"], "fontWeight": "600",
                                                  "fontSize": "13px"}),
                dcc.Checklist(
                    id="filtro-departamento",
                    options=["Human Resources", "Research & Development", "Sales"],
                    value=[],
                    labelStyle={"display": "block", "color": C["texto"], "fontSize": "14px",
                                "padding": "3px 0", "cursor": "pointer"},
                    inputStyle={"marginRight": "8px"},
                    style={"marginBottom": "16px", "marginTop": "6px"},
                ),

                html.Label("Género", style={"color": C["cian"], "fontWeight": "600", "fontSize": "13px"}),
                dcc.Checklist(
                    id="filtro-genero",
                    options=["Female", "Male"],
                    value=[],
                    labelStyle={"display": "block", "color": C["texto"], "fontSize": "14px",
                                "padding": "3px 0", "cursor": "pointer"},
                    inputStyle={"marginRight": "8px"},
                    style={"marginBottom": "16px", "marginTop": "6px"},
                ),

                html.Label("Horas extras", style={"color": C["cian"], "fontWeight": "600",
                                                  "fontSize": "13px"}),
                dcc.RadioItems(
                    id="filtro-overtime",
                    options=[{"label": " Todos", "value": "Todos"},
                             {"label": " Solo con horas extras", "value": "Yes"},
                             {"label": " Solo sin horas extras", "value": "No"}],
                    value="Todos",
                    labelStyle={"display": "block", "color": C["texto"], "fontSize": "14px",
                                "padding": "3px 0", "cursor": "pointer"},
                    inputStyle={"marginRight": "8px"},
                    style={"marginBottom": "16px", "marginTop": "6px"},
                ),

                html.Label("Rango de edad", style={"color": C["cian"], "fontWeight": "600",
                                                   "fontSize": "13px"}),
                html.Div([
                    dcc.RangeSlider(id="filtro-edad", min=18, max=60, step=1, value=[18, 60],
                                    marks={18: "18", 30: "30", 40: "40", 50: "50", 60: "60"},
                                    tooltip={"placement": "bottom"}),
                ], style={"marginTop": "10px"}),
            ], style=ESTILO_TARJETA),
        ], style={"width": "320px", "minWidth": "320px", "padding": "20px 0 20px 20px"}),

        # ===== PANEL DERECHO: KPIs, gráfico, estadísticas, lectura, SQL =====
        html.Div([

            html.Div([
                tarjeta_kpi("kpi-empleados", "Empleados (con filtros)", C["cian"]),
                tarjeta_kpi("kpi-abandono", "Tasa de abandono", C["rosa"]),
                tarjeta_kpi("kpi-overtime", "Hacen horas extras", C["amarillo"]),
                tarjeta_kpi("kpi-satisfaccion", "Satisfacción media", C["verde"]),
            ], style={"display": "flex", "gap": "14px", "marginBottom": "16px"}),

            html.Div([
                html.Div([
                    titulo_seccion("Panel de gráficos", "/assets/panel_graficos.png"),
                    dcc.Graph(id="grafico-principal", style={"height": "460px"}),
                ], style={**ESTILO_TARJETA, "flex": "2.4", "marginBottom": "0"}),
                html.Div([
                    titulo_seccion("Estadísticas", "/assets/panel_graficos.png", alto=28),
                    html.Div(id="panel-estadisticas"),
                ], style={**ESTILO_TARJETA, "flex": "1", "marginBottom": "0"}),
            ], style={"display": "flex", "gap": "14px", "marginBottom": "16px"}),

            html.Div([
                titulo_seccion("Lectura del analista", "/assets/lectura_analista.png", alto=42),
                html.P(id="texto-interpretacion",
                       style={"color": C["texto"], "fontSize": "15px", "lineHeight": "1.6",
                              "margin": "0"}),
            ], style={**ESTILO_TARJETA, "borderLeft": f"4px solid {C['cian']}"}),

            html.Details([
                html.Summary(" Ver la consulta SQL de esta pregunta",
                             style={"color": C["violeta"], "cursor": "pointer", "fontWeight": "600"}),
                html.Pre(id="texto-sql", style={"color": C["verde"], "backgroundColor": C["fondo"],
                                                "padding": "14px", "borderRadius": "8px",
                                                "fontSize": "13px", "overflowX": "auto"}),
            ], style=ESTILO_TARJETA),

        ], style={"flex": "1", "padding": "20px"}),
    ], style={"display": "flex", "alignItems": "flex-start", "maxWidth": "1500px",
              "margin": "0 auto"}),
])


# ---------- 7. CALLBACK ----------

@app.callback(
    Output("grafico-principal", "figure"),
    Output("panel-estadisticas", "children"),
    Output("texto-interpretacion", "children"),
    Output("texto-sql", "children"),
    Output("kpi-empleados", "children"),
    Output("kpi-abandono", "children"),
    Output("kpi-overtime", "children"),
    Output("kpi-satisfaccion", "children"),
    Input("selector-pregunta", "value"),
    Input("filtro-departamento", "value"),
    Input("filtro-genero", "value"),
    Input("filtro-overtime", "value"),
    Input("filtro-edad", "value"),
)
def actualizar_panel(qid, departamentos, genero, overtime, rango_edad):
    """Cada vez que cambias la pregunta o un filtro: WHERE -> SQL -> redibujar."""
    w = construir_where(departamentos, genero, overtime, rango_edad)
    sql = PREGUNTAS[qid]["sql"].format(**w)
    resultado = ejecutar_sql(sql)
    df = datos_filtrados(w)

    if df.empty:
        kpis = ("0", "—", "—", "—")
    else:
        kpis = (
            f"{len(df):,}",
            f"{100 * (df['Attrition'] == 'Yes').mean():.1f}%",
            f"{100 * (df['OverTime'] == 'Yes').mean():.1f}%",
            f"{df['JobSatisfaction'].mean():.2f} / 4",
        )

    figura = crear_grafico(qid, resultado, df)
    estadisticas = calcular_estadisticas(qid, df) if not df.empty else [html.P("Sin datos")]
    interpretacion = interpretar(qid, resultado, df)

    return figura, estadisticas, interpretacion, sql.strip(), *kpis


# ---------- 8. ARRANQUE ----------
if __name__ == "__main__":
    app.run(debug=True)
