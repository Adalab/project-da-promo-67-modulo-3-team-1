# ==========================================================
# consultas_sql.py — Las preguntas del proyecto en SQL
# ==========================================================
# Cada entrada del diccionario asocia un id ("Q1", "Q2"...) con
# su título y su consulta SQL. El marcador {where} se sustituye
# por los filtros activos del dashboard con .format().
#
# Q1-Q10  -> preguntas originales del proyecto (la Q7 se retiró)
# Q11-Q15 -> preguntas añadidas desde fase-3-visualizacion.ipynb
#            (notebook nº 3, 4, 8, 9 y 12; la nº 6 del notebook
#             ya está cubierta por la Q10 "radiografía por puesto")
# ==========================================================

PREGUNTAS = {

    "Q1": {
        "titulo": "1. Satisfacción media: ¿horas extras vs. sin horas extras?",
        "sql": """
            SELECT OverTime AS grupo,
                   ROUND(AVG(JobSatisfaction), 2) AS satisfaccion_media,
                   COUNT(*) AS empleados
            FROM empleados
            {where}
            GROUP BY OverTime;
        """,
    },

    "Q2": {
        "titulo": "2. Tasa de abandono según nivel de satisfacción laboral",
        "sql": """
            SELECT JobSatisfaction AS nivel_satisfaccion,
                   ROUND(100.0 * SUM(CASE WHEN Attrition = 'Yes' THEN 1 ELSE 0 END)
                         / COUNT(*), 1) AS tasa_abandono,
                   COUNT(*) AS empleados
            FROM empleados
            {where}
            GROUP BY JobSatisfaction;
        """,
    },

    "Q3": {
        "titulo": "3. De los que se fueron: ¿Qué % hacía horas extras y tenía satisfacción baja?",
        "sql": """
            SELECT CASE
                     WHEN OverTime = 'Yes' AND JobSatisfaction <= 2 THEN 'Horas extras + Satisf. baja'
                     WHEN OverTime = 'Yes'                          THEN 'Solo horas extras'
                     WHEN JobSatisfaction <= 2                      THEN 'Solo satisf. baja'
                     ELSE 'Ninguno de los dos'
                   END AS perfil,
                   COUNT(*) AS empleados,
                   ROUND(100.0 * COUNT(*) / (SELECT COUNT(*) FROM empleados
                                             {where_sub} Attrition = 'Yes'), 1) AS porcentaje
            FROM empleados
            {where_and} Attrition = 'Yes'
            GROUP BY perfil
            ORDER BY empleados DESC;
        """,
    },

    "Q4": {
        "titulo": "4. Empleados actuales en RIESGO: horas extras + mal balance + baja satisfacción",
        "sql": """
            SELECT Department AS departamento,
                   JobRole AS puesto,
                   COUNT(*) AS empleados_en_riesgo
            FROM empleados
            {where_and} Attrition = 'No'
                    AND OverTime = 'Yes'
                    AND WorkLifeBalance <= 2
                    AND JobSatisfaction <= 2
            GROUP BY Department, JobRole
            ORDER BY empleados_en_riesgo ASC;
        """,
    },

    "Q5": {
        "titulo": "5. Los sobrecargados (horas extras + peor balance), ¿ganan más?",
        "sql": """
            SELECT CASE
                     WHEN OverTime = 'Yes' AND WorkLifeBalance <= 2 THEN 'Sobrecargados'
                     ELSE 'Resto de la plantilla'
                   END AS grupo,
                   ROUND(AVG(MonthlyIncome), 0) AS salario_medio,
                   COUNT(*) AS empleados
            FROM empleados
            {where}
            GROUP BY grupo;
        """,
    },

    "Q6": {
        "titulo": "6. Experiencia vs. salario: ¿beneficia a todos o solo a los cargos altos?",
        "sql": """
            SELECT TotalWorkingYears AS anios_experiencia,
                   MonthlyIncome AS salario_mensual,
                   JobLevel AS nivel_puesto
            FROM empleados
            {where};
        """,
    },

    "Q8": {
        "titulo": "8. ¿Se van los que hacen horas extras?",
        "sql": """
            SELECT OverTime AS horas_extra,
                   ROUND(100.0 * SUM(CASE WHEN Attrition = 'Yes' THEN 1 ELSE 0 END)
                         / COUNT(*), 1) AS tasa_abandono,
                   COUNT(*) AS empleados
            FROM empleados
            {where}
            GROUP BY OverTime;
        """,
    },

    "Q9": {
        "titulo": "9. ¿Se van los que más viajan por trabajo?",
        "sql": """
            SELECT BusinessTravel AS frecuencia_viajes,
                   ROUND(100.0 * SUM(CASE WHEN Attrition = 'Yes' THEN 1 ELSE 0 END)
                         / COUNT(*), 1) AS tasa_abandono,
                   COUNT(*) AS empleados
            FROM empleados
            {where}
            GROUP BY BusinessTravel
            ORDER BY tasa_abandono DESC;
        """,
    },

    "Q10": {
        "titulo": "10. Radiografía por puesto: ¿dónde se concentra el abandono?",
        "sql": """
            SELECT JobRole AS puesto,
                   Department AS departamento,
                   ROUND(100.0 * SUM(CASE WHEN Attrition = 'Yes' THEN 1 ELSE 0 END)
                         / COUNT(*), 1) AS tasa_abandono,
                   ROUND(AVG(JobSatisfaction), 2) AS satisfaccion_media,
                   COUNT(*) AS empleados
            FROM empleados
            {where}
            GROUP BY JobRole, Department
            HAVING COUNT(*) >= 10
            ORDER BY tasa_abandono ASC;
        """,
    },

    "Q11": {
        "titulo": "11. Antigüedad en la empresa según rotación",
        "sql": """
            SELECT Attrition AS estado,
                   YearsAtCompany AS anios_empresa
            FROM empleados
            {where};
        """,
    },

    "Q12": {
        "titulo": "12. El factor económico: ¿cobran menos los que se van?",
        "sql": """
            SELECT Attrition AS estado,
                   MonthlyIncome AS salario_mensual
            FROM empleados
            {where};
        """,
    },

    "Q13": {
        "titulo": "13. ¿A qué edad abandonan la empresa los empleados?",
        "sql": """
            SELECT Attrition AS estado,
                   Age AS edad
            FROM empleados
            {where};
        """,
    },

    "Q14": {
        "titulo": "14. ¿Influye la distancia al trabajo en la rotación?",
        "sql": """
            SELECT Attrition AS estado,
                   DistanceFromHome AS distancia_km
            FROM empleados
            {where};
        """,
    },

    "Q15": {
        "titulo": "15. Relación entre salario y horas extras",
        "sql": """
            SELECT OverTime AS horas_extra,
                   ROUND(AVG(MonthlyIncome), 0) AS salario_medio,
                   COUNT(*) AS empleados
            FROM empleados
            {where}
            GROUP BY OverTime;
        """,
    },
}
